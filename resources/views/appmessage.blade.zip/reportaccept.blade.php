@extends('layouts.app')
@section('title','আপনার রিপোর্ট গ্রহণ করা হল')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
  <div class="card-header">   </div>

<div class="card-body" style="background-color:#fff !important;">


     <h3>আপনার প্ৰতিবেদনটি গ্রহণ করা হল</h3>
   

</div>
   </div>
  </div>
  </div>
    </div>




@endsection