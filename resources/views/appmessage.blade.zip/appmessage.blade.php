@extends('layouts.app')
@section('title','Sirajganj')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
  <div class="card-header">   </div>

<div class="card-body" style="background-color:#fff !important;">

<h3> আপনার আবেদন গ্রহণ করা হলো, এস এম এস মাধ্যমে আপনাকে বিস্তারিত জানিয়ে দেয়া হবে। </h3>
 
<h3 style="text-align:center; "> <a href="./printoption/{{$id}}">আবেদনটি প্রিন্ট করুন </a></h3>


</div>
   </div>
  </div>
  </div>
    </div>




@endsection